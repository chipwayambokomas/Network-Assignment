from queue import Queue
import socket
import sys
import threading
import config

HOST = 'localhost'
PORT = config.SERVER_PORT

input_queue: Queue = Queue()

def input_thread():
    while True:
        message = input()
        if not message:
            continue
        input_queue.put(message)
        
def TCP_con():
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as sock:
        sock.connect((HOST, PORT))
        print(f"Connected to server at {HOST}:{PORT}")
        
        udp_event = threading.Event()
        
        in_thread = threading.Thread(
            target=input_thread
        )
        in_thread.start()

        receive_thread = threading.Thread(
            target=receive_messages, args=(sock,udp_event))
        receive_thread.start()

        send_thread = threading.Thread(target=send_messages, args=(sock,udp_event))
        send_thread.start()
        
        send_thread.join()

        receive_thread.join()

        
    print("Disconnected from server.")

def receive_messages(sock: socket.socket, event):
    while True:
        try:
            data = sock.recv(1024).decode()
            if not data:
                break
            if data.startswith(">") or data.startswith("?"):
                peer_IP = get_peer_IP(data)
                peer_username = get_peer_username(data)
                peer_socknum = get_peer_socknum(data)
                (_ip, my_port) = sock.getsockname()
                event.set()
                threading.Thread(target=UDP_con,args=(my_port, peer_IP, peer_username,int(peer_socknum))).start()
                sock.close()
                break
            
            print(f"{data}")
        except:
            print("Error receiving message (TCP)")
            break


def send_messages(sock, event):
    while True:
        try:
            message = input_queue.get(timeout=0.1)
        except:
            if event.is_set():
                break
            continue
        if not message:
            continue
        try:
            sock.sendall(message.encode())
        except:
            print("Error sending message (TCP)")
            break

def UDP_con(my_port, peer_IP, peer_username, peer_socknum:int):

    # Create a UDP socket
    sock: socket.socket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)

    # Bind the socket to a specific address and port
    server_address = ("", my_port)
    sock.bind(server_address)
    
    TCP_event = threading.Event()

    receive_thread = threading.Thread(target=UDP_receive_messages, args=(sock,peer_username,TCP_event))
    receive_thread.start()

    send_thread = threading.Thread(target=UDP_send_messages, args=(sock,peer_IP, peer_socknum,TCP_event,peer_username))
    send_thread.start()

    receive_thread.join()
    send_thread.join()
    
    print("I am here")
    
    
            
def UDP_receive_messages(sock: socket.socket, peer_username,TCP_event):
    while True:
        try:    
                #print('\nwaiting to receive message')
                (data, address) = sock.recvfrom(4096)
                
                if data.decode() == "/part":
                    print(f"{peer_username} has left the chat.")
                    print(f"Disconnected from {peer_username}")
                    TCP_event.set()
                    sock.close()
                    break

                #print('received {} bytes from {}'.format(len(data), address))
                print(f"{peer_username}: {data.decode()}")
        except:
            print(f"Disconnected from {peer_username}")
            break


def UDP_send_messages(sock: socket.socket, peer_IP, peer_socknum:int, TCP_event,peer_username):
    print(f"Connected to {peer_username} at {peer_IP}:{peer_socknum}")
    server_address = (peer_IP,peer_socknum)
    while True:
        try:
            message = input_queue.get(timeout=0.1)
        except:
            if TCP_event.is_set():
                break
            continue
        if not message:
            continue
        if len(message)==0:
            continue
        if message =="/part":
            sock.sendto(message.encode(), server_address)
            sock.close()
            break
        try:
            #print('sending {!r}'.format(message))
            sock.sendto(message.encode(), server_address)
        except:
            print(f"Disconnected from {peer_username} HERE")
            break


def get_peer_IP(data):
    data = data[2:]
    index_of_a = data.index("@")+1
    index_of_c = data.index(":")
    return data[index_of_a:index_of_c]
    
def get_peer_username(data):
    data = data[2:]
    index = data.index("@")
    return "@"+data[:index]
    
def get_peer_socknum(data):
    index = data.index(":")+1
    return data[index:]
        
    

if __name__ == "__main__":
    TCP_con()
   
